# Wireframe — Consulta de status da vaga (terminal)

O SmartPark é um projeto console (sem tela gráfica), então a "interface" desta
fatia é a saída de terminal, no mesmo padrão já usado em `Main.java`.

```
--- Consulta de status da vaga (Aula 08) ---
Codigo da vaga: A01 -> OK;vaga=A01;tipo=CAR;status=RESERVADA;veiculo=ABC1D23
Codigo da vaga: Z99 -> VAGA_NAO_ENCONTRADA;codigo=Z99
```

- **Entrada:** código da vaga (ex.: `A01`).
- **Ação:** consulta de status (`consultarStatusVaga`).
- **Saída (caminho principal):** vaga, tipo, status e veículo associado.
- **Saída (caminho alternativo):** mensagem indicando vaga não encontrada.

Se o grupo evoluir para uma interface web/mobile futuramente, este mesmo
contrato de entrada/saída pode virar um formulário com campo "Código da vaga"
e um card de resultado — a lógica por trás (serviço) não muda.
