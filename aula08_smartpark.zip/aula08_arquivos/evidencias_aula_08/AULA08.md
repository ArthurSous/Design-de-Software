# Evidência — Aula 08

## Aula
Aula 08 — Fluxo do usuário, interface, modelo, arquitetura e código

## Problema observado
O motorista não tinha como consultar o status de uma vaga (livre, reservada
ou ocupada). A informação já existia no modelo `ParkingSpot`, mas não havia
nenhum ponto de consulta exposto pelo serviço nem pela interface (terminal)
do projeto.

## Alteração realizada
Foi implementada uma fatia mínima de ponta a ponta para o requisito
RF-08-01 — "Consultar status da vaga":

- **Requisito:** `docs/diagramas/diagramas_aula_08/requisito_aula08.md`
- **Fluxo:** `docs/diagramas/diagramas_aula_08/fluxo_aula08.md`
- **Wireframe (terminal):** `docs/diagramas/diagramas_aula_08/wireframe_aula08.md`
- **Modelo (classes e sequência):** `classes_aula08.md`, `sequencia_aula08.md`
- **Arquitetura (componentes e responsabilidades):** `componentes_aula08.md`, `responsabilidades_aula08.md`
- **Código:** método `SmartParkService.consultarStatusVaga(String spotId)` e
  chamada de demonstração em `Main.java`.
- **Rastreabilidade:** `docs/rastreabilidade.md`

## Critério de aceitação
- Dado o código de uma vaga existente, a consulta retorna o status atual
  (`LIVRE`, `RESERVADA` ou `OCUPADA`) e o veículo associado, se houver.
- Dado um código de vaga inexistente, a consulta retorna
  `VAGA_NAO_ENCONTRADA` em vez de lançar exceção.
- O projeto continua compilando e executando sem erro após a alteração.
- Requisito, fluxo, wireframe, modelo, componente e código apontam uns para
  os outros de forma verificável (ver `docs/rastreabilidade.md`).

## Evidências
- Issue: `Aula 08`
- Branch sugerida: `aula08-fluxo-interface-modelo-arquitetura-codigo`
- Diagramas: `docs/diagramas/diagramas_aula_08/`
- Rastreabilidade: `docs/rastreabilidade.md`
- Código alterado: `src/main/java/br/edu/smartpark/service/SmartParkService.java`, `src/main/java/br/edu/smartpark/Main.java`
- Compilação/execução: `evidencias/aula_08/compilacao_aula08.txt`
- Evidência: `evidencias/aula_08/AULA08.md`
- PR: criar no GitHub após subir a branch (ver descrição sugerida abaixo).

## Commits sugeridos
1. `docs: adiciona requisito, fluxo e wireframe da aula 08`
2. `docs: adiciona diagramas de classes, sequencia e componentes da aula 08`
3. `feat: adiciona consulta de status da vaga (RF-08-01)`
4. `docs: registra rastreabilidade e evidencia de compilacao da aula 08`

## Revisão equivalente
Antes de marcar a Issue como concluída: conferir se o método
`consultarStatusVaga` cobre o caminho principal e o alternativo, se o
projeto compila (`scripts/compile.sh`) e se cada artefato da tabela de
rastreabilidade aponta para um arquivo real do repositório.
