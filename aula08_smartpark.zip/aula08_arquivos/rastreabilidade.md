# Rastreabilidade — SmartPark

| Req. | Interface | Modelo | Arquitetura | Código |
|---|---|---|---|---|
| RF-08-01 — Consultar status da vaga | `docs/diagramas/diagramas_aula_08/wireframe_aula08.md` | `docs/diagramas/diagramas_aula_08/classes_aula08.md`, `sequencia_aula08.md` | Componente de Estacionamento (`docs/diagramas/diagramas_aula_08/componentes_aula08.md`) | `SmartParkService.consultarStatusVaga` (`src/main/java/br/edu/smartpark/service/SmartParkService.java`) e chamada em `Main.java` |

> Cada linha nova de rastreabilidade deve apontar para arquivos reais do
> repositório (não para descrições soltas), para que a evidência seja
> verificável.
