# RF-08-01 — Consultar status da vaga

## Problema
O motorista não tem como saber se a vaga associada a ele está livre, reservada
ou ocupada. Essa informação já existe no modelo (`ParkingSpot.occupied`,
`ParkingSpot.reserved`, `ParkingSpot.vehiclePlate`), mas não existe nenhum
ponto de consulta exposto pelo serviço nem pela "interface" (console) do
sistema.

## Requisito
Como motorista, quero consultar o status da vaga informando o código dela,
para saber a situação atual sem precisar perguntar ao operador.

## Leitura do requisito

| Pergunta | Resposta |
|---|---|
| Quem? | Motorista |
| Faz o quê? | Consultar |
| O quê? | Status da vaga |
| Resultado esperado | Visualizar a situação atual da vaga (livre, reservada ou ocupada) |
| Valores possíveis | `LIVRE`, `RESERVADA`, `OCUPADA`, `VAGA_NAO_ENCONTRADA` |

## Escopo
- Não inclui alterar o estado da vaga.
- Não inclui interface gráfica — apenas terminal, como já é o padrão do projeto.
- Não corrige os bugs do backlog da Aula 05 (BP-01 a BP-09); é uma fatia nova
  e independente, só de consulta (somente leitura).
