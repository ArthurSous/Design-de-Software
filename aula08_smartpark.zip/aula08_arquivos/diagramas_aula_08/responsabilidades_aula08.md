# Responsabilidades — RF-08-01

| Parte | Responsabilidade |
|---|---|
| `Main` (terminal) | Receber o código da vaga (simulado no `main`) e imprimir a resposta. |
| `SmartParkService.consultarStatusVaga` | Buscar a vaga, calcular o status (`LIVRE`/`RESERVADA`/`OCUPADA`) e formatar a resposta. |
| `InMemoryRepository<ParkingSpot>` | Buscar a vaga pelo código. |
| `ParkingSpot` | Representar dados e estado da vaga (`occupied`, `reserved`, `vehiclePlate`). |
