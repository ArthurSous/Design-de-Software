# Diagrama de sequência — RF-08-01

```mermaid
sequenceDiagram
    actor Motorista
    participant Main as Main (terminal)
    participant Service as SmartParkService
    participant Repo as InMemoryRepository~ParkingSpot~

    Motorista->>Main: informa codigo da vaga
    Main->>Service: consultarStatusVaga(spotId)
    Service->>Repo: find(spotId)
    Repo-->>Service: ParkingSpot ou null
    alt vaga encontrada
        Service-->>Main: "OK;vaga=...;status=...;veiculo=..."
    else vaga nao encontrada
        Service-->>Main: "VAGA_NAO_ENCONTRADA;codigo=..."
    end
    Main-->>Motorista: exibe resultado no console
```

Diagrama de sequência responde: **o que acontece durante a execução?**
