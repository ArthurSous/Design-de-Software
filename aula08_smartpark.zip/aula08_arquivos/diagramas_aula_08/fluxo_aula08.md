# Fluxo — Consultar status da vaga

```mermaid
flowchart LR
    A[Motorista informa codigo da vaga] --> B[Sistema valida se a vaga existe]
    B -->|vaga encontrada| C[Busca status atual da vaga]
    B -->|vaga nao encontrada| E[Mostra VAGA_NAO_ENCONTRADA]
    C --> D[Mostra status: LIVRE / RESERVADA / OCUPADA]
```

- **Início:** motorista informa o código da vaga.
- **Validação:** existência da vaga no repositório.
- **Caminho principal:** vaga encontrada → status calculado e exibido.
- **Caminho alternativo:** código inexistente → mensagem `VAGA_NAO_ENCONTRADA`.
- **Fim:** motorista entende a situação da vaga.
