# Diagrama de classes — RF-08-01

```mermaid
classDiagram
    class Main {
        +main(args) void
    }
    class SmartParkService {
        +consultarStatusVaga(spotId) String
    }
    class InMemoryRepository~T~ {
        +find(id) T
    }
    class ParkingSpot {
        +id String
        +type String
        +occupied boolean
        +reserved boolean
        +vehiclePlate String
    }

    Main --> SmartParkService : chama
    SmartParkService --> InMemoryRepository~ParkingSpot~ : spots
    InMemoryRepository~ParkingSpot~ --> ParkingSpot : retorna
```

Diagrama de classes responde: **o que existe no sistema para essa
funcionalidade funcionar?** Só entram as classes efetivamente usadas por
`consultarStatusVaga` — nada do restante do legado foi modelado aqui, para
manter a fatia mínima.
