# Diagrama de componentes — RF-08-01

```mermaid
flowchart LR
    subgraph Interface["Interface (terminal)"]
        Main["Main.java"]
    end
    subgraph Dominio["Componente de Estacionamento"]
        Service["SmartParkService"]
    end
    subgraph Persistencia["Persistencia em memoria"]
        Repo["InMemoryRepository"]
    end

    Main -- "consultarStatusVaga(spotId)" --> Service
    Service -- "find(spotId)" --> Repo
```

Diagrama de componentes responde: **em qual parte do sistema essa
funcionalidade fica?** A consulta entra no componente de domínio já
existente (`SmartParkService`), sem criar um componente novo — coerente com
a arquitetura em camadas já declarada no projeto (`docs/arquitetura_inicial.md`).
